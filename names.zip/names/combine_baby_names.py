import pandas as pd
import glob
import os

files = sorted(glob.glob("yob*.txt"))

if not files:
    raise FileNotFoundError("No yobYYYY.txt files found in this folder.")

all_data = []

for file in files:
    year = int(os.path.basename(file)[3:7])
    df = pd.read_csv(file, names=["Name", "Sex", "Count"])
    df["Year"] = year
    all_data.append(df)

baby_names = pd.concat(all_data, ignore_index=True)
baby_names.to_csv("baby_names.csv", index=False)

print(f"Created baby_names.csv with {len(baby_names):,} rows.")